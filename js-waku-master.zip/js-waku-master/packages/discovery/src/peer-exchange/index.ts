export {
  wakuPeerExchange,
  PeerExchangeCodec,
  WakuPeerExchange
} from "./waku_peer_exchange.js";
export {
  wakuPeerExchangeDiscovery,
  PeerExchangeDiscovery,
  Options,
  DEFAULT_PEER_EXCHANGE_TAG_NAME
} from "./waku_peer_exchange_discovery.js";
