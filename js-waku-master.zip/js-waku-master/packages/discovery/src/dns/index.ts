export { PeerDiscoveryDns, wakuDnsDiscovery } from "./dns_discovery.js";
export { enrTree } from "./constants.js";
export { DnsNodeDiscovery } from "./dns.js";
