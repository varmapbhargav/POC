export interface KeepAliveOptions {
  pingKeepAlive: number;
  relayKeepAlive: number;
}
