export type LocalStoragePeerInfo = {
  id: string;
  address: string;
};
