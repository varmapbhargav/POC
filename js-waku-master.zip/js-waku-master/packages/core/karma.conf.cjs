const config = require("../../karma.conf.cjs");

module.exports = config;
