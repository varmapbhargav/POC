# Description

Configuration of CI builds executed under a Jenkins instance at https://ci.status.im/.

# Website

The `Jenkinsfile.gh-pages` file builds the documentation site with this job:
https://ci.infra.status.im/job/website/job/js.waku.org/

And deploys it via `gh-pages` branch and [GitHub Pages](https://pages.github.com/) to:
https://js.waku.org/
